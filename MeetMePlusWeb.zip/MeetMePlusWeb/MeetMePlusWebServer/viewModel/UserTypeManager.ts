import { UserType } from '../model/UserType';
import { UserTypesList } from '../model/UserTypesList';
import { BaseDB } from 'BaseDB';

export class UserTypeManager extends BaseDB {
  protected NewEntity(): UserType {
    return new UserType();
  }

  protected CreateModel(entity: UserType): UserType {
    const userType = entity as UserType;
    userType.id = parseInt(this.reader.rows[0]['id'].toString());
    userType.Name = this.reader.rows[0]['name'].toString();
    return userType;
  }

  public async SelectAll(): Promise<UserTypesList> {
    this.command = 'SELECT * FROM tblusertypes';
    await this.executeQuery();
    const userTypesList = new UserTypesList();
    this.reader.rows.forEach((row: any) => {
      const entity: UserType = this.NewEntity();
      userTypesList.push(this.CreateModel(entity));
    });
    return userTypesList;
  }

  public async SelectById(id: number): Promise<UserType | null> {
    this.command = `SELECT * FROM tblusertypes WHERE id='${id}'`;
    await this.executeQuery();
    const userTypesList = new UserTypesList();
    if (userTypesList.Count === 0) {
      return null;
    }
    return userTypesList[0];
  }

  public async Insert(userType: UserType): Promise<number> {
    this.command = 'INSERT INTO tblusertypes (name) VALUES ($1)';
    this.parameters = [userType.Name];
    return this.SaveChanges();
  }

  public async Update(userType: UserType): Promise<number> {
    this.command = 'UPDATE tblusertypes SET name = $1 WHERE (id = $2);';
    this.parameters = [userType.Name, userType.Id];
    return this.SaveChanges();
  }

  public async Delete(userType: UserType): Promise<number> {
    this.command = 'DELETE FROM tblusertypes WHERE (id = $1)';
    this.parameters = [userType.Id];
    return this.SaveChanges();
  }
}
