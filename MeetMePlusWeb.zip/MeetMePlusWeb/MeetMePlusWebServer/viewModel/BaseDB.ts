import { BaseEntity } from '../model/BaseEntity';
import { Client, QueryResult } from 'pg';


export abstract class BaseDB {
  protected static connectionString: string;
  protected connection: Client;
  protected command: string;
  protected parameters: any[];
  protected reader: QueryResult| null;;

  protected abstract NewEntity(): BaseEntity;
  protected abstract CreateModel(entity: BaseEntity): BaseEntity;

  constructor() {
    if (!BaseDB.connectionString) {
      BaseDB.connectionString =
        'Server=127.0.0.1:5432;User Id=postgres;Password=Sz05056565!;Persist Security Info=True;Database=MeetMePlusDB';
    }
    this.connection = new Client({
      connectionString: BaseDB.connectionString,
    });
    this.command = '';
    this.parameters = [];
    this.reader = null;
  }

  protected async connect(): Promise<void> {
    await this.connection.connect();
  }

  protected async disconnect(): Promise<void> {
    await this.connection.end();
  }

  protected async executeQuery(): Promise<void> {
    await this.connect();
    try {
      this.reader = await this.connection.query(this.command);
    } finally {
      await this.disconnect();
    }
  }

  public async Select(): Promise<BaseEntity[]> {
    const list: BaseEntity[] = [];
    try {
      await this.executeQuery();

      while (this.reader.read()) {
        const entity: BaseEntity = this.NewEntity();
        list.push(this.CreateModel(entity));
      }

    } catch (ex) {
      console.error(ex.message);
    }
    return list;
  }

  public async SaveChanges(): Promise<number> {
    let records = 0;
    try {
      await this.connect();
      const result: QueryResult = await this.connection.query(this.command);
      records = result.rowCount;
    } catch (ex) {
      console.error(ex.message + '\n' + this.command);
    } finally {
      await this.disconnect();
    }
    return records;
  }

  private static Path(): string {
    
    const sub: string[] = __dirname.split('\\');
    const index: number = sub.length - 3;
    sub[index] = 'ViewModel';
    sub.length = index + 1;
    return sub.join('\\');
  }

  public static ProfPath(folders: string): string {
    const sub: string[] = __dirname.split('\\');
    const index: number = sub.length - 2;
    sub[index] = folders;
    sub.length = index + 1;
    return sub.join('\\');
  }
}
