import {BaseEntity} from './BaseEntity';

export class UserType extends BaseEntity {
  name: string;

  constructor(id: number, name: string) {
    super(id);
    this.name = name;
  }
}
