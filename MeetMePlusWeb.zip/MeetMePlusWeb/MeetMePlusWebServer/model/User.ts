import {BaseEntity} from './BaseEntity';
import {UserType} from './UserType';

export class User extends BaseEntity {
  firstName: string;
  lastName: string;
  phone: string;
  password: string;
  email: string;
  gender: boolean;
  username: string;
  birthday: Date;
  interests: string[];
  profPicExt: string;
  userType: UserType;

  constructor(
    id: number,
    firstName: string,
    lastName: string,
    phone: string,
    password: string,
    email: string,
    gender: boolean,
    username: string,
    birthday: Date,
    interests: string[],
    profPicExt: string,
    userType: UserType
  ) {
    super(id);
    this.firstName = firstName;
    this.lastName = lastName;
    this.phone = phone;
    this.password = password;
    this.email = email;
    this.gender = gender;
    this.username = username;
    this.birthday = birthday;
    this.interests = interests;
    this.profPicExt = profPicExt;
    this.userType = userType;
  }

  clone(): User {
    return new User(
      this.id,
      this.firstName,
      this.lastName,
      this.phone,
      this.password,
      this.email,
      this.gender,
      this.username,
      this.birthday,
      [...this.interests],
      this.profPicExt,
      this.userType
    );
  }
}
