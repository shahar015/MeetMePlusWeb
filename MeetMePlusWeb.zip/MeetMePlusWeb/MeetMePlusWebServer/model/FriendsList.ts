import {Friend} from './Friend';

export class FriendsList extends Array<Friend> {
  constructor(list?: Friend[]) {
    if (list) {
      super(...list);
    } else {
      super();
    }
  }
}
