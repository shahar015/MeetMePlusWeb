import {Chat} from './Chat';

export class ChatsList extends Array<Chat> {
  constructor(list?: Chat[]) {
    if (list) {
      super(...list);
    } else {
      super();
    }
  }
}
