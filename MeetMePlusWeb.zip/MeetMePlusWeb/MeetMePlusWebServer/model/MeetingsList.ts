import {Meeting} from './Meeting';

export class MeetingsList extends Array<Meeting> {
  constructor(list?: Meeting[]) {
    if (list) {
      super(...list);
    } else {
      super();
    }
  }
}
