import {UserType} from './UserType';

export class UserTypesList extends Array<UserType> {
  constructor(list?: UserType[]) {
    if (list) {
      super(...list);
    } else {
      super();
    }
  }
}
