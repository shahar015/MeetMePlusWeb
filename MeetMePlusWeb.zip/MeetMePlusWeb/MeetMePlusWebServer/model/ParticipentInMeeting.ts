import {BaseEntity} from './BaseEntity';
import {User} from './User';
import {Meeting} from './Meeting';

export class ParticipentInMeeting extends BaseEntity {
  participent: User;
  meeting: Meeting;

  constructor(id: number, participent: User, meeting: Meeting) {
    super(id);
    this.participent = participent;
    this.meeting = meeting;
  }
}
