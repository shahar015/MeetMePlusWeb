import {BaseEntity} from './BaseEntity';
import {User} from './User';

export class Friend extends BaseEntity {
  user1: User;
  user2: User;

  constructor(id: number, user1: User, user2: User) {
    super(id);
    this.user1 = user1;
    this.user2 = user2;
  }
}
