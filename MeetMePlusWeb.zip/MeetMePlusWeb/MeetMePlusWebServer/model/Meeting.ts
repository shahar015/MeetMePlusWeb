import {BaseEntity} from './BaseEntity';
import {User} from './User';

export class Meeting extends BaseEntity {
  creator: User;
  meetingTime: Date;
  name: string;
  description: string;
  location: string;

  constructor(
    id: number,
    creator: User,
    meetingTime: Date,
    name: string,
    description: string,
    location: string
  ) {
    super(id);
    this.creator = creator;
    this.meetingTime = meetingTime;
    this.name = name;
    this.description = description;
    this.location = location;
  }
}
