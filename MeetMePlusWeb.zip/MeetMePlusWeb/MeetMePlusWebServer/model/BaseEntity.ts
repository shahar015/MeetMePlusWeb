export class BaseEntity {
    id: number;
  
    constructor(id: number) {
      this.id = id;
    }
  }
  