import {User} from './User';

export class UsersList extends Array<User> {
  constructor(list?: User[]) {
    if (list) {
      super(...list);
    } else {
      super();
    }
  }
}
