import {Message} from './Message';

export class MessagesList extends Array<Message> {
  constructor(list?: Message[]) {
    if (list) {
      super(...list);
    } else {
      super();
    }
  }
}
