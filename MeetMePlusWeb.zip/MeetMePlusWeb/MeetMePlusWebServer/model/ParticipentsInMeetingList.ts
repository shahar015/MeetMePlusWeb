import {ParticipentInMeeting} from './ParticipentInMeeting';

export class ParticipentsInMeetingList extends Array<ParticipentInMeeting> {
  constructor(...items: ParticipentInMeeting[]) {
    super(...items);
    Object.setPrototypeOf(this, ParticipentsInMeetingList.prototype);
  }
}
