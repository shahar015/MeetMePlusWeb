import {BaseEntity} from './BaseEntity';
import {User} from './User';
import {Chat} from './Chat';

export class Message extends BaseEntity {
  sendingTime: Date;
  sender: User;
  content: string;
  chat: Chat;

  constructor(id: number, sendingTime: Date, sender: User, content: string, chat: Chat) {
    super(id);
    this.sendingTime = sendingTime;
    this.sender = sender;
    this.content = content;
    this.chat = chat;
  }
}
